//
//  call_lua_dylibTests.h
//  call_lua_dylibTests
//
//  Created by srplab on 13-11-29.
//  Copyright (c) 2013年 srplab. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface call_lua_dylibTests : SenTestCase

@end
