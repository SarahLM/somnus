//
//  call_lua_dylibTests.m
//  call_lua_dylibTests
//
//  Created by srplab on 13-11-29.
//  Copyright (c) 2013年 srplab. All rights reserved.
//

#import "call_lua_dylibTests.h"

@implementation call_lua_dylibTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    STFail(@"Unit tests are not implemented yet in call_lua_dylibTests");
}

@end
