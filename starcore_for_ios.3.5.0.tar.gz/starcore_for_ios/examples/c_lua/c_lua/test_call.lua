print(CClass)

val = CClass("from lua")
val:callback(1234.4564)
val:callback("sdfsdfsdfsdf")
val:SetLuaObject({"aaaaa","bbbbb"});
print("===========end=========")