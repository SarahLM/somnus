//
//  main.m
//  c_lua
//
//  Created by srplab on 14-9-30.
//  Copyright (c) 2014年 srplab. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
