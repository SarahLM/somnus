//
//  call_AddFunctionTests.m
//  call_AddFunctionTests
//
//  Created by srplab on 11/27/12.
//  Copyright (c) 2012 srplab. All rights reserved.
//

#import "call_AddFunctionTests.h"

@implementation call_AddFunctionTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    STFail(@"Unit tests are not implemented yet in call_AddFunctionTests");
}

@end
