//
//  AppDelegate.h
//  c_lua
//
//  Created by srplab on 14-9-30.
//  Copyright (c) 2014年 srplab. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

