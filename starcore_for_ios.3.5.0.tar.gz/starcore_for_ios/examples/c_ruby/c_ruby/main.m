//
//  main.m
//  c_ruby
//
//  Created by srplab on 15/5/10.
//  Copyright (c) 2015年 srplab. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
