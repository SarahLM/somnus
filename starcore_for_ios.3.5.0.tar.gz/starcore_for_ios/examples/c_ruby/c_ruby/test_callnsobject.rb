print($CClass)

bb=$CClass.initTestSRPClass("aaaaaaaaaaaaaaa")
bb.usingPointer(bb)

print("===========end=========")