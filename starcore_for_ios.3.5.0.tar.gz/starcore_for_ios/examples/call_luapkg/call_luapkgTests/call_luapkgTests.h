//
//  call_luapkgTests.h
//  call_luapkgTests
//
//  Created by srplab on 11/27/12.
//  Copyright (c) 2012 srplab. All rights reserved.
//

#import <XCTest/XCTest.h>

@interface call_luapkgTests : XCTestCase

@end
